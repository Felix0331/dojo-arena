$(document).ready(function(){
    $('.dropDowns').hide();
    // $('#beach').click()
    // $('#planet').click();
    // $('#dojo').click();
    // $('#forest').click();
    // $('#matrix').click();
    // $('#snow').click();
    $('.playerImg').hide();

    $('#beach').hover(function (){
        $('.background').css('background-image', 'url(beach.jpg)');
    })
    $('#beach').click(function (){
        changeBox();
    })
    $('#planet').hover(function(){
        $('.background').css('background-image', 'url(earth.jpg)');
    });
    $('#planet').click(function (){
        changeBox();
    })
    $('#dojo').hover(function(){
        $('.background').css('background-image', 'url(dojo.jpg)');
    });
    $('#dojo').click(function (){
        changeBox();
    })
    $('#forest').hover(function(){
        $('.background').css('background-image', 'url(forest.jpg)');
    });
    $('#forest').click(function (){
        changeBox();
    })
    $('#matrix').hover(function(){
        $('.background').css('background-image', 'url(matrix.jpg)');
    });
    $('#matrix').click(function (){
        changeBox();
    })
    $('#snow').hover(function(){
        $('.background').css('background-image', 'url(snow.jpg)');
    });
    $('#snow').click(function (){
        changeBox();
    })

    function changeBox(){
        $('.arena-box button').hide();
        $('.arena-box h1').hide();
        $('.dropDowns').show();
        //Show other box stuff
        
    }

    var pictureList = [
        "donny.png",
        "leo.png",
        "mikey.png",
        "raphael.png"
         ];
    
    $('#picDD').change(function () {
        var val = parseInt($('#picDD').val());
        $('img').attr("src",pictureList[val]);
        $('.playerImg').show();
    });

})